/**THIS IS NOT MY CODE!
  *This is code taken from Dr.Bareiss
  *@author Dr.Bareiss
  *Code used for simon game, lab 3
  *For Grant Ross taken from class examples
  */
public class QueueUnderflowException extends RuntimeException {
    public QueueUnderflowException() {
        super();
    }
    public QueueUnderflowException(String message) {
        super(message);
    }
}