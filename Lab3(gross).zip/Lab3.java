/** Description of class
  *
  * @author		Grant Ross
  * @id			gross
  * @course		Programming II
  * @assignment		SimonGame lab
  * @related		IODriver
  * @included		Lab3
  */
import java.util.Scanner;
import java.io.*;
public class Lab3
{
    public static void main(String[] args)throws IOException
    { 
     SimonGame game = new SimonGame();  
     game.start(); //start game               
     
    } 
}
   


