/**THIS IS NOT MY CODE!
  *This is code taken from Dr.Bareiss
  *@author Dr.Bareiss
  *Code used for simon game, lab 3
  *For Grant Ross taken from class examples
  */
public class QueueOverflowException extends RuntimeException {
    public QueueOverflowException() {
        super();
    }//overflow exception
    public QueueOverflowException(String message) {
        super(message);
    }
}